package com.esiot.datafire;

public class Post {

    public String suhu;
    public String kelembapan;

    public Post(String suhu, String kelembapan) {
        // ...
    }

}
